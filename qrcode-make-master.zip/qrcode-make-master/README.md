# qrcode-make
Creating a Qrcode which translates to whatever u want after being scanned.
Simple code.
Used qrcode module.
Tweak the code and make ur own qrcode 
The qrcode will be saved in the same file as your other python programs in png mode.
Happy coding :)
