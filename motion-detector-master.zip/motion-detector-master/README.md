# motion-detector
A python program used to detect motion using OpenCV
