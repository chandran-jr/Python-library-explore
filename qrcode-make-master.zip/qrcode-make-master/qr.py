import qrcode

qr= qrcode.make('Hello this is Govind B Chandran and heres a qr code i have made using this very simple code and the qrcode module.Happy coding :)')
qr.save('myQR.png')
